=== timagazine ===

Timagazine, Copyright 2017
Timagazine is distributed under the terms of the GNU GPL

License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Description

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Menus ===

Primary

== Credits ==

* Underscores
  http://underscores.me/, (C) 2012-2016 Automattic, Inc.,
  [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)

* TGM
  TGM-Plugin http://tgmpluginactivation.com/
  2.6.1 for parent theme boka for publication on WordPress.org
  license   GPL-2.0+
  Thomas Griffin, Gary Jones, Juliette Reinders Folmer
  Copyright (c) 2011, Thomas Griffin

* WP Bootstrap Navwalker
  Version: 2.0.4
  Author: Edward McIntyre https://github.com/twittem/wp-bootstrap-navwalker
  License: GPL-2.0+
  License URI: http://www.gnu.org/licenses/gpl-2.0.txt

* FontAwesome
  Font Awesome 4.7.0
  Copyright: Dave Gandy
  Resource URI: http://fontawesome.io
  License: SIL Open Font License, Version 1.1
  License URI: http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)

* Bootstrap
  Bootstrap v4.0.0-beta (https://getbootstrap.com)
  Copyright 2011-2017 The Bootstrap Authors
  Copyright 2011-2017 Twitter, Inc.
  Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)

* Popper
  Copyright (C) Federico Zivolo 2017
  Distributed under the MIT License (license terms are at http://opensource.org/licenses/MIT).

* Masonry v4.2.0  https://masonry.desandro.com MIT License by David DeSandro

* Chosen https://github.com/harvesthq/chosen ,(C) Harvest, [MIT](http://opensource.org/licenses/MIT)s

* Image (used in screenshot)
